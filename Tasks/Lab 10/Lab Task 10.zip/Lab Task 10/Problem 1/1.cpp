#include <iostream>

using namespace std;

void calculator (float air , float cb , int months)
{  
   int i , d , d1 = 0 , w , w1 = 0 , inter , to_in ;
   for (i = 1 ; i <= months ; i++)
   {
      cout<< "Enter Amount Deposited : " << endl;
      cin>> d ;
      if ( d != 0 )
      {
         d1 = d1 + 1;
      }
      
      while (d < 0)
      {
         cout<< "Invalid Input! Enter Again : " << endl;
         cin>> d ;
      }
      cb = cb + d;
      if (cb < 0)
      {
       cout << "Account Closed ! " ;
       return ;
      }
      
      cout<< "Enter Amount Withdrawn : " << endl;
      cin>> w ;
      if ( d != 0 )
      {
         w1 = w1 + 1;
      }
      while (w < 0)
      {
         cout<< "Invalid Input! Enter Again : " << endl;
         cin>> w ;
      }
      if (cb < 0)
      {
       cout << "Account Closed ! " ;
       return  ;
      }
      cb = cb - w;  
      inter = cb * air ;
      to_in = to_in + inter ;
      cb = cb + inter ;
      if (cb < 0)
      {
       cout << "Account Closed ! " ;
       return ;
      }
   }
   if (cb < 0)
      {
       cout << "Account Closed ! " ;
       return ;
      }
   
   cout<< " Number of times of Deposits : " << d1 << endl ;
   cout<< " Number of times of Withdraws : " << w1 << endl ;
   cout<< " Total Interest Earned : " << to_in << endl ;
   cout<< " Balance of Savings Accounts : " << cb << endl;
}

int main ()
{
   float air , cb ; 
   int months ;
   cout<< "Enter Annual Interest Rate : " << endl;
   cin>> air ;
   air = (air / 1200);
   cout<< "Enter Starting Balance : " << endl;
   cin>> cb ;
   cout<< "Enter the months that have passed since account has been established : " << endl ;
   cin>> months;

   calculator (air , cb , months);


   return 0;
}
