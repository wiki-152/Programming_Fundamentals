#include <iostream>

using namespace std;

void sales (int i1 , int i2 , int i3 , int i4 , int i5 )
{
   int i = 0;
   i1 = i1 / 50 ;
   cout << "Store 1 Sales : " ;
   for (i = 1 ; i <= i1 ; i++)
   {
      cout<<"x";
   }
   cout << endl << "Store 2 Sales : ";
   i2 = i2 / 50 ;
   for (i = 1 ; i <= i2 ; i++)
   {
      cout<<"x";
   }
   cout << endl << "Store 3 Sales : ";
   i3 = i3 / 50 ;
   for (i = 1 ; i <= i3 ; i++)
   {
      cout<<"x";
   }
   cout << endl << "Store 4 Sales : ";
   i4 = i4 / 50 ;
   for (i = 1 ; i <= i4 ; i++)
   {
      cout<<"x";
   }
   cout << endl << "Store 5 Sales : ";
   i5 = i5 / 50 ;
   for (i = 1 ; i <= i2 ; i++)
   {
      cout<<"x"<< endl;
   }
}
int main ()
{
   int i1 , i2 , i3 , i4 , i5 ;
   cout<< "Sales Store 1 : ";
   cin>> i1;
   cout<< "Sales Store 2 : ";
   cin>> i2;
   cout<< "Sales Store 3 : ";
   cin>> i3;
   cout<< "Sales Store 4 : ";
   cin>> i4;
   cout<< "Sales Store 5 : ";
   cin>> i5;

   sales (i1 , i2 , i3 , i4 , i5);
   
return 0;
}
