#include <iostream>

using namespace std;

int checkPrimeNumber (int input)
{
  
   int i = 0  , b = 0 ;
   int a = 0;
   while (input > 0)
  {
   for (i = 1 ; i <= input ; i++)
      {   
         a = (input % i ) ;
        
         if (a == 0)
         {
            b = b + 1;
         }
      }
      if (b <3)
      {   cout<< input << " is a prime number!"<< endl;
      }
      else 
      cout<< input << " is not a prime number!" << endl;
      b = 0;
      cout<< "Enter Integer Number : " ;
      cin>> input;
  }
  return 0;
}

int main ()
{
   int input ;
   cout<< "Enter Integer Number : " ;
   cin>> input;

  cout << checkPrimeNumber (input) ; 

  cout<< "Negative Number Entered So Program Exiting!" << endl ;



   return 0;
}


