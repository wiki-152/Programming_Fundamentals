#include <iostream>

using namespace std;

int number (int input)
{
 int no = 0;
 int count = 0;
 int a = 0;
 
   while (no == 0)
   {
      a = input % 2;
      if (a == 1)
      {
         count = count + 1;
      }
      input = input / 2;
      if (input == 0)
      {
        break;
      }
   }
return count ;
} 

int main ()
{

int input;
cout<< "Enter Number : ";
cin>> input;

cout<< "Number of 1(s) : " << number (input) << endl;


return 0;
}
