#include <iostream>

using namespace std;

void diagram ()
   {
      int a1 = 5 , a2 = 10 , a3 = 0;
      for (int i = 1 ; i <= 6 ;i++)
      {
         for (int a = 0 ; a < a1 ; a++) // left 6 stars
         {
            cout<< "*";
         }
         
         for (int b = 0; b < i ; b++) // Left side Space
         {
            cout<< " ";
         }
         
         for (int c = 0; c < a2 ;c++) // from left Forward Slash
         {
            cout<< "/";
         }
         a2 = a2 - 2;
         for (int d = a3 ; d > 0; d--) // Backward slash increasing from right to left 
         {
            cout<< "\\";
         }
         a3 = a3 + 2;
         for (int b = 0; b < i ; b++ ) // right side space
         {
            cout<<" ";
         }
         for (int a = 0; a < a1 ; a++) // right side stars
         {
            cout<< "*";
         }
         cout<< endl;  // For Line End
         a1-- ;
        }
    
   }

int main ()
{

diagram();



return 0;
}
