#include <iostream>

using namespace std;

float sum ( float a,float b) ;
float subtract (float a , float b) ;
float multiply (float a , float b) ;
float divide (float a , float b) ;
int   mod (int  a , int b) ;

int main () {
float a,b ;

cout<< "Enter first number : " ;
cin>> a ;

cout<< "Enter second number : " ;
cin>> b;

cout<< "Sum is : " << sum (a , b) << endl ;
cout<< "Subtraction is : " << subtract ( a , b) << endl ;
cout<< "Multiplied  is : " << multiply ( a , b) << endl ;
cout<< "Divided is : " << divide ( a , b) << endl ;
cout<< "Mod is : " << mod ( a , b) << endl ;
return 0 ;
}

float sum (float a , float b) {
 // float sum; then sum =a+b; also possible method
return a+b;
}

float subtract (float a , float b) {
 return a-b ;
}

float multiply (float a , float b) {
 return  a*b ;
}

float divide (float a , float b) {
 return  a/b ;
}

int mod (int a , int b) {
 return a&b ;
}






