#include <iostream>
#include <cmath>

using namespace std;

float angle3 (float a1 , float a2) ;

int main () {
float a1,a2;

cout<< "Enter the first angle : " ;
cin>> a1;

cout<< "Enter the second angle : " ;
cin>> a2 ;

cout<<"The third angle will be : " << angle3 (a1 , a2) << endl;

return 0 ;
}

float angle3 (float a1 , float a2) {

return 180 - a1 - a2 ; 
}
