#include <iostream>
#include <cmath>

using namespace std;

float volume (float radius) ;

int main () {
float radius = 0 ;

cout<< "Enter the radius of sphere : " ;
cin>> radius ;

cout<< "The volume of sphere is : " << volume (radius) << endl ;

return 0 ;
}

float volume (float radius) {
return 1.33333333 * (M_PI * (pow(radius,3))) ; 
}
