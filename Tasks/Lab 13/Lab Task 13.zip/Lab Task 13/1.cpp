#include <iostream>

using namespace std;

int main ()
{
   char ttt [3][3];
   int inputrow1 , inputcolumn1 , inputrow2, inputcolumn2 ;
   for (int i=0 ; i<3 ; i++)
   {
       for (int j=0 ; j< 3 ; j++)
       {
          ttt[i][j]= '*';
          cout<< ttt[i][j] << " |" ;
       }
   
     cout<<endl;
     cout<<"---------";
     cout<<endl;
   }
   
   cout<<endl<<endl;
   
   int turn = 1;
  while (true)
  {
  
    if (turn==1)
    {
    cout<<"Player 1 Enter Row : ";
    cin>>inputrow1;
    cout<<"Player 1 Enter Column : ";
    cin>>inputcolumn1;
    inputrow2 = -1;
    inputcolumn2 = -1;
    }
    if (turn==2)
    {
    cout<<"Player 2 Enter Row : ";
    cin>>inputrow2;
    cout<<"Player 2 Enter Column : ";
    cin>>inputcolumn2;
    inputrow1 = -1;
    inputcolumn1 = -1;
    }
    if (turn==3)
    {
    cout<<"Player 1 Enter Row : ";
    cin>>inputrow1;
    cout<<"Player 1 Enter Column : ";
    cin>>inputcolumn1;
    inputrow2 = -1;
    inputcolumn2 = -1;
    }
    if (turn==4)
    {
    cout<<"Player 2 Enter Row : ";
    cin>>inputrow2;
    cout<<"Player 2 Enter Column : ";
    cin>>inputcolumn2;
    inputrow1 = -1;
    inputcolumn1 = -1;
    }
    if (turn==5)
    {
    cout<<"Player 1 Enter Row : ";
    cin>>inputrow1;
    cout<<"Player 1 Enter Column : ";
    cin>>inputcolumn1;
    inputrow2 = -1;
    inputcolumn2 = -1;
    }
    if (turn==6)
    {
    cout<<"Player 2 Enter Row : ";
    cin>>inputrow2;
    cout<<"Player 2 Enter Column : ";
    cin>>inputcolumn2;
    inputrow1 = -1;
    inputcolumn1 = -1;
    }
    if (turn==7)
    {
    cout<<"Player 1 Enter Row : ";
    cin>>inputrow1;
    cout<<"Player 1 Enter Column : ";
    cin>>inputcolumn1;
    inputrow2 = -1;
    inputcolumn2 = -1;
    }
    if (turn==8)
    {
    cout<<"Player 2 Enter Row : ";
    cin>>inputrow2;
    cout<<"Player 2 Enter Column : ";
    cin>>inputcolumn2;
    inputrow1 = -1;
    inputcolumn1 = -1;
    
    }
    if (turn==9)
    {
    cout<<"Player 1 Enter Row : ";
    cin>>inputrow1;
    cout<<"Player 1 Enter Column : ";
    cin>>inputcolumn1;
    inputrow2 = -1;
    inputcolumn2 = -1;
    }
    
    for (int i = 0; i< 3 ; i++)
    {
      
      for (int j=0 ; j<3 ; j++)
      {
         if (inputrow1==i && inputcolumn1 ==j)
         {
             ttt[i][j]= '1';
            cout<<ttt[i][j]<<" |";
         }
         else if (ttt[i][j] != '1' or ttt[i][j] != '2'){ttt[i][j]= '*';
          cout<< ttt[i][j] << " |" ;}
         if (inputrow2==i && inputcolumn2==j)
         {
            ttt[i][j]= '2';
            cout<<ttt[i][j]<<" |";
         }
                  else if (inputrow2!=-1 && inputcolumn1!=-1 && (ttt[i][j] != '1' or ttt[i][j] != '2')){ttt[i][j]= '*';
          cout<< ttt[i][j] << " |" ;}
      }
      cout<<endl;
      cout<<"----------";
      cout<<endl;
    } 
    
   if (turn==4)
   {
       if ((ttt[0][0]==ttt[0][1] && ttt[0][1]==ttt[0][2]) or (ttt[1][0]==ttt[1][1] && ttt[1][1]==ttt[1][2]) or (ttt[2][0]==ttt[2][1] && ttt[2][1]==ttt[2][2]) or (ttt[0][0]==ttt[1][0] && ttt[1][0]==ttt[2][0]) or (ttt[0][1]==ttt[1][1] && ttt[1][1]==ttt[1][2]) or (ttt[2][0]==ttt[2][1] && ttt[2][1]==ttt[2][2]) or (ttt[0][0]==ttt[1][1] && ttt[1][1]==ttt[2][2]) or ((ttt[2][0]==ttt[1][1] && ttt[1][1]==ttt[2][0])) && ttt[0][0]=='1'
    )
    {
      cout<<"Player 1 Wins!";
      break;
    }
    
           if ((ttt[0][0]==ttt[0][1] && ttt[0][1]==ttt[0][2]) or (ttt[1][0]==ttt[1][1] && ttt[1][1]==ttt[1][2]) or (ttt[2][0]==ttt[2][1] && ttt[2][1]==ttt[2][2]) or (ttt[0][0]==ttt[1][0] && ttt[1][0]==ttt[2][0]) or (ttt[0][1]==ttt[1][1] && ttt[1][1]==ttt[1][2]) or (ttt[2][0]==ttt[2][1] && ttt[2][1]==ttt[2][2]) or (ttt[0][0]==ttt[1][1] && ttt[1][1]==ttt[2][2]) or ((ttt[2][0]==ttt[1][1] && ttt[1][1]==ttt[2][0])) && (ttt[0][0]=='2' or ttt[0][1]=='2')
    )
    {
      cout<<"Player 2 Wins!";
      break;
    }
    
   }
    if (turn==10)
    {
    cout<<"Draw";
    break;
    }
    turn++;
  }










    return 0 ; 
}
