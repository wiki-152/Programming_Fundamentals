#include <iostream>

using namespace std;

double add (double num1 , double num2 ) 
{
return num1 + num2 ;
}

double sub (double num1 , double num2 ) 
{
return num1 - num2 ;
}

double mult (double num1 , double num2 ) 
{
return num1 * num2 ;
}

double div (double num1 , double num2 ) 
{
return num1 / num2 ;
}

int mod (int num1 , int num2 ) 
{
return num1 % num2 ;
}





int main () 
{
  cout<< "(+) For Addition " << endl ;
  cout<< "(-) For Subtraction " << endl ;
  cout<< "(*) For Multiplication " << endl ;
  cout<< "(/) For Division " << endl ;
  cout<< "(%) For Mod " << endl ;

char a ; 
double num1 , num2 ;

cout << "Enter NUM1 : " ;
cin>> num1 ;

cout<< "Enter NUM2 : " ;
cin>> num2 ;

cout<< "Enter Character For Operation : " ;
cin>> a ;

switch (a) 
{
case '+' : 
cout<< "Answer is " << add (num1 , num2 ) << endl ;
break;

case '-' : 
cout<< "Answer is " << sub (num1 , num2 ) << endl ;
break;

case '*' : 
cout<< "Answer is " << mult (num1 , num2 ) << endl ;
break;

case '/' : 
cout<< "Answer is " << div (num1 , num2 ) << endl ;
break;

case '%' : 
cout<< "Answer is " << mod (num1 , num2 ) << endl ;
break;
}

return 0 ;
}
