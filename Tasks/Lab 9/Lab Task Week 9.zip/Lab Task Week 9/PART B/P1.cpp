#include <iostream>

using namespace std;

void check (int day , int month , int year) ;

int main()
{
 int day , month , year ;
 
 cout<< "Enter Day (Numeric Form) : " ;
 cin>> day ;
 
 cout<< "Enter Month (Numeric Form) : " ;
 cin>> month ;
 
 cout<< "Enter Year (Numeric Form) : " ;
 cin>> year ;
 
 check (day , month , year) ;

return 0;
}

void check (int day , int month , int year) 
{

if ((day * month) == year)
{
 cout<< "The Date is Magic ! " ;
} 
else cout<< "The Date is not Magic ! " ;

}


 

