#include <iostream>

using namespace std;

void check (double num)
{
if (num < 60)
{
cout<< num << " seconds " << endl ; // FALTU
}

if (num >= 60 && num<3600)
{
cout<< num / 60 << " minutes in "<< num << " seconds"  << endl ;
}
if (num >=3600 && num < 86400)
{
cout<< num / 3600 << " hours in " << num << " seconds" << endl;
}
if (num >= 86400)
{
cout<< num / 86400 << " days in " << num << " seconds" << endl;
}
}

int main () {

double num = 0 ;

cout<< "Enter a number : " ;
cin>> num ;

check (num) ;


return 0;
}
