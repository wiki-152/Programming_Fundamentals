#include <iostream>
#include <string>

using namespace std;

// FN 1
void sa (double balance , double a1)
{
 cout<< "Enter Your Balance : " ;
 cin>> balance ;
 
 if (balance < 200) {
 cout<< "You have been charged 10$ as your balance is below minimum! " << endl ;
 balance = balance - 10 ;
 cout<< "Your balance is " << balance << endl ;
 }
 
 if (balance >= 200) {
  a1 = balance * 0.04 ;
  balance = balance + a1 ;
  cout<< "Your Balance After Interest is : " << balance ; 
  }
 }

//FN 2
void ca (double balance , double a1)
{
 cout<< "Enter Your Balance : " ;
 cin>> balance ;
 
 if (balance <= 5200)
    if (balance < 200)
 {
 cout<< "You have been charged 25$ as your balance is below minimum! " << endl ;
 balance = balance - 25 ;
 cout<< "Your Balance is " << balance << endl ;
 }
 else {
 a1 = balance * 0.03;
 balance = a1 + balance ;
 cout<< "You have been given 3 Percent interest! Your Balalnce is " << balance << endl ;
 }
 
 if (balance > 5200 )
 {
 a1 = 0.05 * balance ;
 balance = a1 + balance ;
 cout<< "You have been given 5 Percent interest! Your Balalnce is " << balance << endl ;
 }
}

int main () 
{
  int a = 0 ;
  cout<< "Enter 1 For Saving Account or 2 For Checking Account : " ;
  cin>> a ;
 
 double balance , a1 ;
 
 switch (a) {
 case 1 :
 sa (balance , a1) ;
 break ;
 
 case 2 :
 ca (balance , a1) ;
 break;
 }

return 0;
}
