#include <iostream>
#include <cmath>

using namespace std;

float area (float r) ;

float area (float b , float h);

float area (float a , float b1 , float h1);

int main () 
{

float r,b,h,a,b1,h1;

cout<< "Enter the radius of circle : ";
cin>> r;

cout<< "Enter base and height of triangle : " ;
cin>> b >> h;

cout<< "Enter side a , side b and height of trapezium : ";
cin>> a >> b1 >> h1;

cout<<"Area of circle is : " << area (r) << endl;
cout<<"Area of triangle is : " << area (b , h) << endl;
cout<<"Area of trapezium is : " << area (a , b1 , h1) << endl;

return 0; 
}


float area (float r) 
{
return M_PI * pow(r,2) ;
}

float area (float b , float h) 
{
return 0.5 * b * h ;
}

float area (float a , float b1 , float h1 ) 
{
return (a+b1)* h1 / 2;
}

