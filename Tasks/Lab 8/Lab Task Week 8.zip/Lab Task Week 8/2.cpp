#include <iostream>
#include <cmath>
#include <math.h>

using namespace std;

float velocity ( float v1 = 0.03 , float a1 = 0.0003142 , float a2 = 20  ) 
{
float v2 = v1 * a1 / a2 ; 
return v2 ;
}
int main () 
{

cout<< "The average speed of blood in capillaries will be : " << velocity ();

return 0;
}





