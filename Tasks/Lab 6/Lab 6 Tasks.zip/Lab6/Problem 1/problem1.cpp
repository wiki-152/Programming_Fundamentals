#include<iostream>
#include<cmath>

using namespace std;

int main () {

int a = 0; 
int b = 1;

cout<< "Enter a number : " ;
cin>> a;

while (b < a) {
 if ( a % b == 0) {
   cout<< b << " is a factor of the entered number " << endl; 
 }
 b++;
} 


return 0;
}
