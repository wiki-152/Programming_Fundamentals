Start

Declare integer num = 0;
Declare integer num1 = 1;

Display "Enter a number " ;
Input num ;

while ( num1 < num ) then 
      if ( num mod num1 = 0 ) then 
      Display << num1 << " is a factor.";
      end if 
  num1++ ;
end while        

End
