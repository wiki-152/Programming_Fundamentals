#include <iostream>
#include <cmath>
#include <math.h>
 
using namespace std;

int main () {

float raorta = 1.0 ;
raorta = raorta * pow (10,-2) ;

float v1 = 30.0 ;
v1 = v1 * pow (10,-2);

float a1 = 0 ;

float d2 = 8 * pow (10,-4) ;
d2 = d2 * pow (10,-2);

float a2 = 2000 * pow (10,-2) ;

float v2 = 0 ;

float pi = 3.141592653589793238 ;

v2 = (pi * pow (raorta,2) * v1) / a2 ;

cout << "The average speed of blood in capillaries is " << v2 << endl; 





return 0 ;
}
