#include <iostream>

using namespace std;

int main () {

int num1;

cout<< "Enter a 5 digit number : " ;
cin>> num1 ;

cout<< num1/10000 << " is first digit" << endl;
num1 = num1 % 10000; 

cout << num1 / 1000 << " is second digit" << endl;
num1 = num1 % 1000;

cout << num1 / 100 << " is third digit" << endl ;
num1 = num1 % 100;

cout << num1 / 10 << " is fourth digit" << endl ;
num1 = num1 % 10;

cout << num1 << " is fifth digit"<< endl;



return 0;
}
